<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mahasiswa;

class MahasiswaController extends Controller
{
    public function index(){
        $data=Mahasiswa::all();
        return view("list-mahasiswa", ["mahasiswas" => $data]);
    }

    public function show(Mahasiswa $mahasiswa){
        return view("detail",["mahasiswa" => $mahasiswa]);
    }

    public function create(){
        return view("formCreate");
    }

    public function edit(Mahasiswa $mahasiswa){
        return view("formEdit",["mahasiswa" => $mahasiswa]);
    }

    public function store(Request $request, Mahasiswa $mahasiswa){
        $validated = $request->validate([
            "nim" => "required|size:10|unique:mahasiswas",
            "nama" => "required|max:50",
            "jenis_kelamin" => "required|in:P,L",
            "jurusan" => "required",
            "alamat" => "required",
        ]);

        Mahasiswa::create($validated);
        return redirect("/mahasiswas") ->with("pesan", "Penambahan data". $validated['nama'] ."berhasil");
    }

    public function update(Request $request, Mahasiswa $mahasiswa){
        $validated = $request->validate([
            "nim" => "required|size:10",
            "nama" => "required|max:50",
            "jenis_kelamin" => "required|in:P,L",
            "jurusan" => "required",
            "alamat" => "required",
        ]);

        $mahasiswa->update($validated);
        return redirect("/mahasiswas") ->with("pesan", "pengubahan data". $validated['nama'] ."berhasil");
    }

    public function destroy( Mahasiswa $mahasiswa){
        $mahasiswa->delete();
        return redirect("mahasiswas")
        ->with("pesan", "hapus data $mahasiswa->nama berhasil");
    }
}
